# rviz에 waypoints 찍은 것들이 /clicked_point에 담겨 있어서 다른 파일로 저장하는 코드
# 없다면 이 부분 보완하고 다시 코드 만들고 실행해서 waypoint로 가는 방법 생각해야됨

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
import json
import signal

class WaypointRecorder(Node):
    def __init__(self):
        super().__init__('waypoint_recorder')
        self.points = []
        self.subscription = self.create_subscription(
            PointStamped,
            '/clicked_point',
            self.point_callback,
            10)
        self.get_logger().info('Waypoint Recorder Started. Click points in RViz.')
        
        # 종료 시그널 처리
        signal.signal(signal.SIGINT, self.shutdown_hook)
    
    def point_callback(self, msg):
        self.get_logger().info(f'Point received: x={msg.point.x:.2f}, y={msg.point.y:.2f}')
        self.points.append({
            'x': msg.point.x,
            'y': msg.point.y,
            'z': msg.point.z
        })
    
    def shutdown_hook(self, signum, frame):
        self.get_logger().info('Shutdown signal received. Saving points to waypoints.json...')
        self.save_points()
        rclpy.shutdown()

    def save_points(self):
        with open('waypoints.json', 'w') as f:
            json.dump(self.points, f, indent=2)
        self.get_logger().info(f'{len(self.points)} points saved to waypoints.json')

def main(args=None):
    rclpy.init(args=args)
    recorder = WaypointRecorder()
    rclpy.spin(recorder)
    recorder.destroy_node()

if __name__ == '__main__':
    main()