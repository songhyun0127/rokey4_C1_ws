import json
from typing import List, Tuple

class WaypointManager:
    def __init__(self, json_path: str = "/home/rokey/Documents/waypoints/waypoint_1.json"):
        self.json_path = json_path
        self.waypoints = []  # List of tuples: (name, x, y, direction)
        self.load_waypoints()

    def load_waypoints(self):
        with open(self.json_path, 'r') as f:
            data = json.load(f)

        for point in data['waypoints']:
            name = point['name']            # ⚠️ 'name' 필드는 변경 가능성 있음
            x = point['x']
            y = point['y']
            direction = point['direction']  # ⚠️ 'direction' 필드는 숫자 혹은 문자열일 수 있음
            self.waypoints.append((name, x, y, direction))

    def get_waypoints_by_names(self, target_names: List[str]) -> List[Tuple[str, float, float, str]]:
        selected = []
        for target in target_names:
            match = next((wp for wp in self.waypoints if wp[0] == target), None)
            if match:
                selected.append(match)
            else:
                print(f"[경고] '{target}' 이름의 waypoint를 찾을 수 없습니다.")
        return selected
