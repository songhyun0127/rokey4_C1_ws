# from collections import deque
# from std_msgs.msg import String
# from rclpy.node import Node

# class DeliveryQueue:
#     def __init__(self, node: Node = None):
#         self.queue = deque()
#         self.node = node

#         if self.node:
#             self.node.create_subscription(
#                 String,
#                 '/order_topic',
#                 self.delivery_callback,
#                 10
#             )

#     def delivery_callback(self, msg: String):
#         order_name = msg.data.strip()
#         if order_name:
#             self.queue.append(order_name)
#             if self.node:
#                 self.node.get_logger().info(f"배송 요청 수신: {order_name}")

#     def is_empty(self) -> bool:
#         return len(self.queue) == 0

#     def get_next_request(self):
#         if not self.is_empty():
#             return [self.queue.popleft()]  # 리스트 형태로 반환해 WaypointManager에 전달 가능하게
#         return []


import json
from collections import deque
from std_msgs.msg import String
from rclpy.node import Node

class DeliveryQueue:
    def __init__(self, node: Node = None):
        self.queue = deque()
        self.node = node

        if self.node:
            self.node.create_subscription(
                String,
                '/order_topic',
                self.delivery_callback,
                10
            )

    def delivery_callback(self, msg: String):
        try:
            order_dict = json.loads(msg.data)
            name = order_dict.get("name")
            direction = order_dict.get("direction")

            if name and direction:
                self.queue.append({"name": name, "direction": direction})
                if self.node:
                    self.node.get_logger().info(f"배송 요청 수신: {name}, 방향: {direction}")
            else:
                if self.node:
                    self.node.get_logger().warn("JSON에 'name' 또는 'direction' 누락됨.")
        except json.JSONDecodeError:
            if self.node:
                self.node.get_logger().error("JSON 디코딩 실패. 메시지 형식 확인 필요.")

    def is_empty(self) -> bool:
        return len(self.queue) == 0

    def get_next_request(self):
        if not self.is_empty():
            return self.queue.popleft()
        return None