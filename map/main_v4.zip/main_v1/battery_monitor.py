import rclpy
from rclpy.node import Node
from sensor_msgs.msg import BatteryState

class BatteryMonitor(Node):
    """
    TurtleBot4의 배터리 상태를 구독하여 퍼센트를 관리합니다.
    퍼센트는 0.0~1.0 단위로 제공되므로 100을 곱해 실제 퍼센트로 계산합니다.
    ROS 기본 토픽: /battery_state 또는 /<namespace>/battery_state
    """

    def __init__(self, namespace: str = ""):
        sanitized_ns = namespace.strip('/')

        node_name = f"{sanitized_ns}_battery_monitor" if namespace else "battery_monitor"
        super().__init__(node_name)

        topic_name = f"/{sanitized_ns}/battery_state" if namespace else "/battery_state"
        self.subscription = self.create_subscription(
            BatteryState,
            topic_name,
            self.battery_callback,
            10
        )

        self.last_battery_percent = 100.0  # 시작 시 최대치로 가정
        self.is_docked = False

    def battery_callback(self, msg: BatteryState):
        """
        battery_state 메시지를 수신하고 배터리 퍼센트를 기록합니다.
        """
        self.last_battery_percent = msg.percentage * 100.0
        self.get_logger().info(f"배터리 잔량: {self.last_battery_percent:.1f}%")

    def is_battery_low(self, threshold: float = 40.0) -> bool:
        """
        배터리 잔량이 기준 이하인지 여부를 반환합니다.
        """
        return self.last_battery_percent <= threshold

    def is_battery_enough_to_depart(self, threshold: float = 80.0) -> bool:
        """
        도킹 해제 후 이동 가능한 잔량인지 확인합니다.
        """
        return self.last_battery_percent >= threshold

def main(args=None):
    rclpy.init(args=args)
    monitor = BatteryMonitor(namespace="/robot8")
    rclpy.spin(monitor)
    monitor.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
