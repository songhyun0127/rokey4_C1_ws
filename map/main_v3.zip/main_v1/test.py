import rclpy
from rclpy.node import Node
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Navigator, TurtleBot4Directions
from geometry_msgs.msg import PoseStamped

from rokey_hub.main_v1.docking_manager import DockingManager
from rokey_hub.main_v1.battery_monitor import BatteryMonitor

# navigator 객체 래핑 (DockingManager의 navigator가 사용하는 형태 맞춤)
class NavigatorWrapper:
    def __init__(self, node: Node):
        self.node = node
        self.navigator = TurtleBot4Navigator()
        initial_pose = self.navigator.getPoseStamped([0.0, 0.0], TurtleBot4Directions.NORTH)
        self.navigator.setInitialPose(initial_pose)
        self.navigator.waitUntilNav2Active()

def main():
    rclpy.init()
    node = rclpy.create_node('docking_test_node')

    # BatteryMonitor를 node에 붙여줌
    node.battery_monitor = BatteryMonitor(namespace="robot8")  # ⚠️ 실제 네임스페이스 확인
    # ✅ 1. 배터리 상태 수신을 위한 spin 실행
    rclpy.spin_once(node.battery_monitor, timeout_sec=2.0)  # 또는 반복문으로 spin 여러 번 해도 됨

    # ✅ 2. 수신된 배터리 퍼센트 출력
    percent = node.battery_monitor.last_battery_percent
    node.get_logger().info(f"수신된 배터리 잔량: {percent:.1f}%")
    navigator = NavigatorWrapper(node)
    docking_manager = DockingManager(navigator)

    # 언도킹 후 도킹, 충전 완료까지 대기
    docking_manager.undock()
    rclpy.spin_once(node, timeout_sec=2.0)  # 잠깐 spin 해서 배터리 콜백 수신
    docking_manager.dock_until_charged(threshold=80.0)

    node.get_logger().info("테스트 완료.")
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()


# waypoint_manager
# delivery_queue
# battery_monitor
# docking_manager