from collections import deque
from std_msgs.msg import String
from rclpy.node import Node

class DeliveryQueue:
    def __init__(self, node: Node = None):
        self.queue = deque()
        self.node = node

        if self.node:
            self.node.create_subscription(
                String,
                '/order_topic',
                self.delivery_callback,
                10
            )

    def delivery_callback(self, msg: String):
        order_name = msg.data.strip()
        if order_name:
            self.queue.append(order_name)
            if self.node:
                self.node.get_logger().info(f"배송 요청 수신: {order_name}")

    def is_empty(self) -> bool:
        return len(self.queue) == 0

    def get_next_request(self):
        if not self.is_empty():
            return [self.queue.popleft()]  # 리스트 형태로 반환해 WaypointManager에 전달 가능하게
        return []
