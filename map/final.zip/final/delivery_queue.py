from collections import deque
from std_msgs.msg import String
from rclpy.node import Node

class DeliveryQueue:
    def __init__(self, node: Node = None):
        self.queue = deque()
        self.node = node
        if self.node:
            self.node.create_subscription(
                String,
                '/target_waypoints',
                self.delivery_callback,
                10
            )

    def delivery_callback(self, msg: String):
        try:
            parts = [s.strip() for s in msg.data.split(',') if s.strip()]
            if len(parts) != 2:
                if self.node:
                    self.node.get_logger().warn(f"🚫 잘못된 형식: {msg.data}")
                return
            
            a, b = parts
            self.queue.append((a, b))
            if self.node:
                self.node.get_logger().info(f"📥 배송 요청 수신: ({a}, {b})")
        except Exception as e:
            if self.node:
                self.node.get_logger().error(f"❌ 예외 발생: {e}")

    def is_empty(self) -> bool:
        return len(self.queue) == 0

    def get_next_request(self):
        if not self.is_empty():
            return self.queue.popleft()  # (a, b) 튜플 반환
        return None