from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions, TurtleBot4Navigator
from nav2_simple_commander.robot_navigator import TaskResult
from geometry_msgs.msg import PoseStamped
import rclpy


class Navigator:
    def __init__(self, node):
        self.node = node
        self.navigator = TurtleBot4Navigator()

        initial_pose = self.navigator.getPoseStamped(
            [0.0, 0.0],  # 위치 (x, y)
            TurtleBot4Directions.EAST  # 방향 (NORTH, EAST, etc.)
        )
        self.navigator.setInitialPose(initial_pose)
        self.navigator.waitUntilNav2Active()

    def follow_waypoints(self, goal_poses: list[PoseStamped]):
        self.node.get_logger().info(f"Waypoint 개수: {len(goal_poses)}")

        if len(goal_poses) == 1:
            self.navigator.goToPose(goal_poses[0])

            # ✅ 실제 도달 여부 확인
            self.node.get_logger().info("🕒 목표 도달 대기 중...")
            while not self.navigator.isTaskComplete():
                rclpy.spin_once(self.node, timeout_sec=0.5)

            result = self.navigator.getResult()
        else:
            result = self.navigator.followWaypoints(goal_poses)

        if result == TaskResult.SUCCEEDED:
            self.node.get_logger().info("✅ 모든 waypoint 도달 완료")
        else:
            self.node.get_logger().warn("❌ waypoint 이동 중 실패")

    def go_to_pose(self, pose: PoseStamped):
        self.navigator.goToPose(pose)
