import rclpy
from rclpy.node import Node

from waypoint_manager import WaypointManager
from .delivery_queue import DeliveryQueue
from battery_monitor import BatteryMonitor
from docking_manager import DockingManager
from navigator import Navigator

class MainController(Node):
    def __init__(self):
        super().__init__('main_controller')
        self.get_logger().info('TurtleBot Delivery System Initialized')

        self.navigator = Navigator(self)
        self.waypoint_manager = WaypointManager()
        self.delivery_queue = DeliveryQueue(self)
        self.battery_monitor = BatteryMonitor(namespace=self.get_namespace())
        self.docking_manager = DockingManager(self.navigator)

        # self.yolo_tracker = YoloTracker(self)  # 추후 사용 시 주석 해제

        self.timer = self.create_timer(1.0, self.control_loop)  # 1초 주기 루프

    def control_loop(self):
        if self.battery_monitor.is_battery_low():
            self.get_logger().info("배터리 부족으로 도킹 시작")
            self.docking_manager.dock_until_charged()
            return

        if self.delivery_queue.is_empty():
            self.get_logger().info("배송 요청 없음. 대기 중...")
            return

        target = self.delivery_queue.get_next_request()
        self.get_logger().info(f"배송 시작: {target}")

        goal_poses = self.waypoint_manager.get_waypoints_by_names(target)
        self.docking_manager.undock()
        self.navigator.follow_waypoints(goal_poses)
        self.docking_manager.dock()


def main(args=None):
    rclpy.init(args=args)
    node = MainController()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()