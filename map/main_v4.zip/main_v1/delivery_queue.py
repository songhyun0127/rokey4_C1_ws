import json
from collections import deque
from std_msgs.msg import String
from rclpy.node import Node

class DeliveryQueue:
    def __init__(self, node: Node = None):
        self.queue = deque()
        self.node = node

        if self.node:
            self.node.create_subscription(
                String,
                '/target_waypoints',
                self.delivery_callback,
                10
            )

    def delivery_callback(self, msg: String):
        names = [s.strip() for s in msg.data.split(',') if s.strip()]
        if names:
            self.queue.append(names)
            if self.node:
                self.node.get_logger().info(f"📥 배송 요청 수신: {names}")
        else:
            if self.node:
                self.node.get_logger().warn("🚫 유효한 Waypoint 이름 없음")

    def is_empty(self) -> bool:
        return len(self.queue) == 0

    def get_next_request(self):
        if not self.is_empty():
            return self.queue.popleft()  # 이름 리스트 반환
        return []