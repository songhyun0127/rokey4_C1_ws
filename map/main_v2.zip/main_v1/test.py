import rclpy
from rclpy.node import Node
from .delivery_queue import DeliveryQueue  # 같은 디렉토리에 있다고 가정

class TestNode(Node):
    def __init__(self):
        super().__init__('delivery_queue_test')
        self.queue_manager = DeliveryQueue(self)

def main(args=None):
    rclpy.init(args=args)
    node = TestNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


# waypoint_manager
# delivery_queue
# battery_monitor