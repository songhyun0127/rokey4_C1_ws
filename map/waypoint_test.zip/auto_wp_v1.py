#!/usr/bin/env python3

import rclpy
import json
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions, TurtleBot4Navigator

def load_waypoints_from_json(json_path):
    waypoints = []

    with open(json_path, 'r') as f:
        data = json.load(f)

    for point in data['waypoints']:
        name = point['name']
        x = point['x']
        y = point['y']
        direction = point['direction']
        waypoints.append((name, x, y, direction))

    return waypoints

def main():
    rclpy.init()

    json_path = "/home/jadu/final_project/src/rokey_hub/rokey_hub/waypoint/waypoint_1.json"
    waypoint_data = load_waypoints_from_json(json_path)

    navigator = TurtleBot4Navigator()

    # Start on dock
    if not navigator.getDockedStatus():
        navigator.info('Docking before initializing pose')
        navigator.dock()

    # Set initial pose
    initial_pose = navigator.getPoseStamped([0.0, 0.0], TurtleBot4Directions.NORTH)
    navigator.setInitialPose(initial_pose)

    # Wait for Nav2
    navigator.waitUntilNav2Active()

    # ✅ 원하는 순서대로 name 리스트 정의
    target_names = ['cross', 'home3', 'home2']

    goal_pose = []
    for target_name in target_names:
        found = False
        for name, x, y, direction in waypoint_data:
            if name == target_name:
                try:
                    direction_enum = getattr(TurtleBot4Directions, direction.upper())
                except AttributeError:
                    print(f"[경고] 방향 '{direction}' 은 잘못된 값입니다. '{name}' 건너뜁니다.")
                    continue
                pose = navigator.getPoseStamped([x, y], direction_enum)
                goal_pose.append(pose)
                navigator.info(f"Waypoint 추가됨: {name} ({x}, {y}) 방향 {direction}")
                found = True
                break
        if not found:
            print(f"[경고] '{target_name}' 이름을 가진 waypoint를 JSON에서 찾을 수 없습니다.")

    # 비어 있는 경우 처리
    if not goal_pose:
        navigator.error("유효한 goal_pose가 없습니다. 종료합니다.")
        rclpy.shutdown()
        return

    # Undock
    navigator.undock()

    # Follow Waypoints
    navigator.startFollowWaypoints(goal_pose)

    # Finished navigating, dock
    navigator.dock()

    rclpy.shutdown()

if __name__ == '__main__':
    main()
