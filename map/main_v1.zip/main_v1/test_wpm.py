from waypoint_manager import WaypointManager

def main():
    wm = WaypointManager("/home/jadu/final_project/src/rokey_hub/rokey_hub/waypoint/waypoint_1.json")
    targets = ["cross", "home1", "hub9"]  # hub9는 없는 항목 (에러 메시지 확인용)
    result = wm.get_waypoints_by_names(targets)

    print("📌 추출된 웨이포인트 목록:")
    for r in result:
        print(r)

if __name__ == "__main__":
    main()