# 차량 detect 없이 자율 주행 가능한지 테스트 파일

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
import json
from tf_transformations import quaternion_from_euler

class WaypointFollower(Node):
    def __init__(self):
        super().__init__('waypoint_follower')
        self.navigator = BasicNavigator()

    def load_waypoints(self, filename):
        with open(filename, 'r') as f:
            data = json.load(f)
        
        waypoints = []
        for pt in data:
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.pose.position.x = pt['x']
            pose.pose.position.y = pt['y']
            pose.pose.position.z = pt.get('z', 0.0)

            # yaw 없으면 0, 있으면 쿼터니언 변환
            yaw = pt.get('yaw', 0.0)
            q = quaternion_from_euler(0, 0, yaw)
            pose.pose.orientation.x = q[0]
            pose.pose.orientation.y = q[1]
            pose.pose.orientation.z = q[2]
            pose.pose.orientation.w = q[3]

            waypoints.append(pose)
        return waypoints

    def run(self):
        self.get_logger().info("Waiting for Nav2 to become active...")
        self.navigator.waitUntilNav2Active()

        waypoints = self.load_waypoints('waypoints.json')
        self.get_logger().info(f"Loaded {len(waypoints)} waypoints")

        result = self.navigator.followWaypoints(waypoints)
        if result == TaskResult.SUCCEEDED:
            self.get_logger().info("Successfully reached all waypoints!")
        else:
            self.get_logger().error("Failed to reach waypoints")

def main(args=None):
    rclpy.init(args=args)
    node = WaypointFollower()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()