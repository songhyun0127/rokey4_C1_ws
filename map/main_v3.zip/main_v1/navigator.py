from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Directions, TurtleBot4Navigator
from nav2_simple_commander.robot_navigator import TaskResult
from geometry_msgs.msg import PoseStamped


class Navigator:
    def __init__(self, node):
        self.node = node
        self.navigator = TurtleBot4Navigator()
        self.navigator.setInitialPose()
        self.navigator.waitUntilNav2Active()

    def follow_waypoints(self, goal_poses: list[PoseStamped]):
        self.node.get_logger().info(f"Waypoint 개수: {len(goal_poses)}")
        result = self.navigator.follow_waypoints(goal_poses)

        if result == TaskResult.SUCCEEDED:
            self.node.get_logger().info("모든 waypoint 도달 완료")
        else:
            self.node.get_logger().warn("waypoint 이동 중 실패")

    def go_to_pose(self, pose: PoseStamped):
        self.navigator.goToPose(pose)
