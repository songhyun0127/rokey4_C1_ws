import time
from nav2_simple_commander.robot_navigator import TaskResult
import rclpy

class DockingManager:
    def __init__(self, navigator):
        self.navigator = navigator

    def dock(self):
        self.navigator.navigator.dock()

        # ✅ 도킹 완료 대기
        self.navigator.node.get_logger().info("🧲 도킹 중...")
        while not self.navigator.navigator.isTaskComplete():
            rclpy.spin_once(self.navigator.node, timeout_sec=0.5)

        result = self.navigator.navigator.getResult()
        if result == TaskResult.SUCCEEDED:
            self.navigator.node.get_logger().info("✅ 도킹 완료")
        else:
            self.navigator.node.get_logger().warn("❌ 도킹 실패")


    def undock(self):
        self.navigator.navigator.undock()
        self.navigator.node.get_logger().info("언도킹 완료")

    def dock_until_charged(self, battery_monitor, threshold: float = 80.0):
        self.dock()
        self.navigator.node.get_logger().info("충전 중... 80% 이상 충전되면 출발 가능")

        while battery_monitor.last_battery_percent < threshold:
            rclpy.spin_once(battery_monitor, timeout_sec=1.0)
            time.sleep(1.0)

        self.navigator.node.get_logger().info("충전 완료. 배송 재개 가능.")