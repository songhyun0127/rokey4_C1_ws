# gui가 있어서 실제 디텍팅 되는지 검증 가능
# 다만 실제 시연할때는 gui가 없는 버전으로 해야 연산량을 감소시킬 수 있다.  

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Twist
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge
from ultralytics import YOLO
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Navigator, TurtleBot4Directions
from std_msgs.msg import Header
import threading
import numpy as np
import json
import cv2
import time


class YoloWaypointFollower(Node):
    def __init__(self):
        super().__init__('yolo_waypoint_follower')

        self.bridge = CvBridge()
        self.lock = threading.Lock()

        self.rgb_topic = '/oakd/rgb/image_raw/compressed'
        self.create_subscription(CompressedImage, self.rgb_topic, self.rgb_callback, 10)

        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.rgb_image = None
        self.display_image = None

        # YOLO 모델 불러오기
        self.model = YOLO("/home/your_path/my_best.pt")  # 경로 수정

        # 네비게이터 초기화 및 Undock
        self.navigator = TurtleBot4Navigator()
        self.navigator.waitUntilNav2Active()

        init_pose = self.navigator.getPoseStamped([0.0, 0.0], TurtleBot4Directions.NORTH)
        self.navigator.setInitialPose(init_pose)

        self.get_logger().info("Loading waypoints...")
        self.waypoints = self.load_waypoints("/home/your_path/waypoints.json")  # 경로 수정
        self.get_logger().info(f"{len(self.waypoints)} waypoints loaded.")

        self.gui_thread = threading.Thread(target=self.gui_loop, daemon=True)
        self.gui_thread.start()

        self.timer = self.create_timer(0.5, self.detect_and_control)

        self.started = False
        self.stop_motion = False

    def load_waypoints(self, path):
        with open(path, 'r') as f:
            data = json.load(f)
        waypoints = []
        for pt in data['waypoints']:
            pose = PoseStamped()
            pose.header = Header(frame_id='map')
            pose.pose.position.x = pt['x']
            pose.pose.position.y = pt['y']
            pose.pose.orientation.w = pt.get('w', 1.0)
            waypoints.append(pose)
        return waypoints

    def rgb_callback(self, msg):
        try:
            arr = np.frombuffer(msg.data, np.uint8)
            image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            with self.lock:
                self.rgb_image = image
        except Exception as e:
            self.get_logger().error(f"RGB decode failed: {e}")

    def detect_and_control(self):
        with self.lock:
            rgb = self.rgb_image.copy() if self.rgb_image is not None else None

        if rgb is None:
            return

        result = self.model(rgb, verbose=False)[0]
        detected = False
        speed = 0.3  # 기본 속도

        for det in result.boxes:
            cls = int(det.cls[0])
            label = self.model.names[cls]
            conf = float(det.conf[0])
            x1, y1, x2, y2 = map(int, det.xyxy[0].tolist())

            if label.lower() != 'car':
                continue

            detected = True
            u = (x1 + x2) // 2
            width = x2 - x1

            # 거리 유추: 박스 넓이 기반 간단 추정
            approx_distance = 300 / width  # 튜닝 필요

            if approx_distance < 0.6:
                speed = 0.0
            elif approx_distance < 1.5:
                speed = 0.15
            else:
                speed = 0.25

            cv2.rectangle(rgb, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(rgb, f"{label} {conf:.2f} d~{approx_distance:.2f}m",
                        (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        self.display_image = rgb

        twist = Twist()
        twist.linear.x = speed
        self.cmd_vel_pub.publish(twist)

        # Waypoint 주행 시작 (최초 1회만)
        if not self.started:
            self.get_logger().info("Starting waypoint navigation...")
            self.navigator.followWaypoints(self.waypoints)
            self.started = True

    def gui_loop(self):
        cv2.namedWindow("Detection", cv2.WINDOW_NORMAL)
        while rclpy.ok():
            with self.lock:
                img = self.display_image.copy() if self.display_image is not None else None
            if img is not None:
                cv2.imshow("Detection", img)
                if cv2.waitKey(1) == 27:
                    self.get_logger().info("Shutdown by ESC")
                    rclpy.shutdown()
                    break


def main():
    rclpy.init()
    node = YoloWaypointFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    cv2.destroyAllWindows()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
