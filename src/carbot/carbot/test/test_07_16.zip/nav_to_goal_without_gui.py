# gui 없는 버전
# 제대로 구동만 된다면 아마 완성 코드가 될 가능성이 있겠지만
# 내가 나를 안믿고 내가 gpt를 안믿기 때문에 보완해야됨

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped, Quaternion
from sensor_msgs.msg import CompressedImage, CameraInfo, Image
from cv_bridge import CvBridge
from tf_transformations import quaternion_from_euler
from turtlebot4_navigation.turtlebot4_navigator import TurtleBot4Navigator, TurtleBot4Directions
from ultralytics import YOLO
import numpy as np
import threading
import json
import time

class WaypointWithFollowCar(Node):
    def __init__(self):
        super().__init__('waypoint_follow_with_car_control')

        # --- Navigator 준비 ---
        self.navigator = TurtleBot4Navigator()
        if not self.navigator.getDockedStatus():
            self.get_logger().info('Docking before initializing pose')
            self.navigator.dock()
        init_pose = self.navigator.getPoseStamped([0.0, 0.0], TurtleBot4Directions.NORTH)
        self.navigator.setInitialPose(init_pose)
        self.navigator.waitUntilNav2Active()
        self.navigator.undock()

        # --- YOLO 모델 로딩 ---
        self.model = YOLO("/home/hihigiig101/Downloads/my_best.pt")

        # --- 영상 및 카메라 정보 토픽 설정 ---
        ns = self.get_namespace()
        self.rgb_topic = f'{ns}/oakd/rgb/image_raw/compressed'
        self.depth_topic = f'{ns}/oakd/stereo/image_raw'
        self.info_topic = f'{ns}/oakd/rgb/camera_info'

        self.bridge = CvBridge()
        self.lock = threading.Lock()

        self.rgb_image = None
        self.depth_image = None
        self.K = None
        self.camera_frame = None

        # --- cmd_vel 퍼블리셔 (속도 제어용) ---
        self.cmd_vel_pub = self.create_publisher(Twist, f'{ns}/cmd_vel', 10)

        # --- 구독자 ---
        self.create_subscription(CompressedImage, self.rgb_topic, self.rgb_callback, 10)
        self.create_subscription(Image, self.depth_topic, self.depth_callback, 10)
        self.create_subscription(CameraInfo, self.info_topic, self.camera_info_callback, 10)

        # --- waypoints 로딩 및 네비게이터 실행 ---
        self.waypoints = self.load_waypoints('waypoints.json')
        self.get_logger().info(f'Loaded {len(self.waypoints)} waypoints')

        # --- 감지 및 주행 타이머 ---
        self.detection_timer = self.create_timer(0.3, self.detect_car_and_control_speed)

        # --- 속도 상태 변수 ---
        self.car_detected = False
        self.last_detection_time = 0.0
        self.min_speed = 0.1
        self.max_speed = 0.3
        self.current_speed = self.max_speed

        # --- 별도 쓰레드에서 waypoint 따라가기 ---
        self.nav_thread = threading.Thread(target=self.follow_waypoints_thread, daemon=True)
        self.nav_thread.start()

    def load_waypoints(self, filepath):
        with open(filepath, 'r') as f:
            data = json.load(f)
        poses = []
        for pt in data:
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.pose.position.x = pt['x']
            pose.pose.position.y = pt['y']
            pose.pose.position.z = pt.get('z', 0.0)
            yaw = pt.get('yaw', 0.0)
            q = quaternion_from_euler(0, 0, yaw)
            pose.pose.orientation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])
            poses.append(pose)
        return poses

    def follow_waypoints_thread(self):
        # Nav2의 followWaypoints는 blocking 호출이라 별도 쓰레드에서 실행
        result = self.navigator.followWaypoints(self.waypoints)
        if result == 0:  # TaskResult.SUCCEEDED
            self.get_logger().info('Successfully followed all waypoints!')
        else:
            self.get_logger().error(f'Failed to follow waypoints: {result}')

    def camera_info_callback(self, msg):
        self.K = np.array(msg.k).reshape(3, 3)
        self.camera_frame = msg.header.frame_id
        self.get_logger().info(f"Camera info received: fx={self.K[0,0]:.2f}")

    def rgb_callback(self, msg):
        try:
            arr = np.frombuffer(msg.data, np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            with self.lock:
                self.rgb_image = img
        except Exception as e:
            self.get_logger().error(f"RGB decode error: {e}")

    def depth_callback(self, msg):
        try:
            depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
            with self.lock:
                self.depth_image = depth
        except Exception as e:
            self.get_logger().error(f"Depth decode error: {e}")

    def detect_car_and_control_speed(self):
        with self.lock:
            rgb = self.rgb_image.copy() if self.rgb_image is not None else None
            depth = self.depth_image.copy() if self.depth_image is not None else None
            K = self.K

        if rgb is None or depth is None or K is None:
            return

        result = self.model(rgb, verbose=False)[0]
        car_detected = False
        for det in result.boxes:
            cls = int(det.cls[0])
            label = self.model.names[cls]
            if label.lower() != 'car':
                continue
            car_detected = True

            x1, y1, x2, y2 = map(int, det.xyxy[0].tolist())
            u = (x1 + x2) // 2
            v = (y1 + y2) // 2

            z = float(depth[v, u]) / 1000.0  # m 단위 변환
            if not (0.3 < z < 5.0):
                continue

            target_distance = 1.0
            max_speed = 0.3
            min_speed = 0.1

            # 속도 비례 제어
            if z < 0.4:
                speed = 0.0
            else:
                speed = max(min_speed, min(max_speed, (z - target_distance) * 0.7))

            self.current_speed = speed
            self.publish_speed(speed)

            self.get_logger().info(f"Car detected at {z:.2f}m, speed set to {speed:.2f} m/s")
            break

        if not car_detected:
            # 차가 안 보이면 max 속도 유지
            self.current_speed = self.max_speed
            self.publish_speed(self.current_speed)
            self.get_logger().info("No car detected, running at max speed")

    def publish_speed(self, speed):
        twist = Twist()
        twist.linear.x = speed
        twist.angular.z = 0.0
        self.cmd_vel_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = WaypointWithFollowCar()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
